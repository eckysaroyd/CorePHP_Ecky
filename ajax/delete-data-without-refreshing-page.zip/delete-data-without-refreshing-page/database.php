<?php
$database = new PDO("mysql:host=localhost;dbname=db_search", 'root', '');
?>