Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/return-json-response-ajax-using-jquery-php/

Instructions - 

* Import attached users.sql file in your MySQL database.
* Update config.php file.